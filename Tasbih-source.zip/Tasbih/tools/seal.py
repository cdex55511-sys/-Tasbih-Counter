#!/usr/bin/env python3
"""Recomputes the Content-Security-Policy script hash in index.html. Run after every edit of the page."""
import re, hashlib, base64, pathlib
p = pathlib.Path(__file__).resolve().parent.parent / 'app/src/main/assets/index.html'
h = p.read_text(encoding='utf-8')
h = re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>\n?', '', h)
m = re.search(r'<script>(.*?)</script>', h, re.S)
assert m, 'no inline script found'
d = base64.b64encode(hashlib.sha256(m.group(1).encode('utf-8')).digest()).decode()
csp = ("default-src 'none'; script-src 'sha256-%s'; style-src 'unsafe-inline'; img-src data:; media-src data:; "
       "connect-src 'none'; font-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'" % d)
tag = '<meta http-equiv="Content-Security-Policy" content="%s">\n' % csp
assert '<meta charset="utf-8">\n' in h
h = h.replace('<meta charset="utf-8">\n', '<meta charset="utf-8">\n' + tag, 1)
p.write_text(h, encoding='utf-8')
print('sealed, script hash sha256-' + d)
