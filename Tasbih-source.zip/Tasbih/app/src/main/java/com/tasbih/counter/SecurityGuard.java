package com.tasbih.counter;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Debug;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Runtime self-defence. Any "block" result stops the app; "warn" results are shown once to the user. */
final class SecurityGuard {
    /** true = refuse to run on rooted devices. Default is warn-only so a custom ROM cannot lock you out. */
    static final boolean BLOCK_ROOTED = false;

    static final class Verdict {
        String block;
        final List<String> warn = new ArrayList<>();
    }

    static Verdict scan(Context c) {
        Verdict v = new Verdict();
        if (!BuildConfig.DEBUG && debuggerAttached(c)) v.block = "A debugger is attached to the app.";
        else if (hooked()) v.block = "A code-injection tool (Frida or Xposed) was detected in the app.";
        else if (!signatureOk(c)) v.block = "This copy of Tasbih is not signed with your key. It may have been modified or repackaged. Install only the APK you built.";
        else if (!assetsOk(c)) v.block = "The app's files have been modified.";
        if (rooted()) {
            if (BLOCK_ROOTED && v.block == null) v.block = "This device is rooted.";
            else v.warn.add("This device looks rooted, so other apps may be able to read this app's data.");
        }
        List<String> acc = riskyAccessibility(c);
        if (!acc.isEmpty())
            v.warn.add("These accessibility apps are active and can read what is on screen: " + String.join(", ", acc) + ". Turn off any you do not recognise.");
        return v;
    }

    private static boolean debuggerAttached(Context c) {
        if ((c.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) return true;
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) return true;
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/status"))) {
            String l;
            while ((l = r.readLine()) != null)
                if (l.startsWith("TracerPid:")) return !l.substring(10).trim().equals("0");
        } catch (Exception e) { }
        return false;
    }

    private static boolean hooked() {
        try { Class.forName("de.robv.android.xposed.XposedBridge"); return true; } catch (Throwable t) { }
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/self/maps"))) {
            String l;
            while ((l = r.readLine()) != null) {
                String s = l.toLowerCase(Locale.ROOT);
                if (s.contains("frida") || s.contains("gum-js") || s.contains("xposed") || s.contains("lsposed") || s.contains("substrate")) return true;
            }
        } catch (Exception e) { }
        return false;
    }

    @SuppressWarnings("deprecation")
    private static boolean signatureOk(Context c) {
        String want = BuildConfig.CERT_SHA256;
        if (want == null || want.isEmpty()) return true;   // unsigned/debug builds skip this check
        try {
            PackageManager pm = c.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                SigningInfo si = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES).signingInfo;
                if (si == null || si.hasMultipleSigners()) return false;
                sigs = si.getApkContentsSigners();
            } else {
                sigs = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNATURES).signatures;
            }
            if (sigs == null || sigs.length != 1) return false;
            String got = hex(MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray()));
            return MessageDigest.isEqual(got.getBytes(StandardCharsets.UTF_8), want.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { return false; }
    }

    private static boolean assetsOk(Context c) {
        try (InputStream in = c.getAssets().open("index.html")) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            return MessageDigest.isEqual(hex(md.digest()).getBytes(StandardCharsets.UTF_8), BuildConfig.ASSET_SHA256.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { return false; }
    }

    private static boolean rooted() {
        String[] p = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/su/bin/su", "/data/local/xbin/su",
            "/data/local/bin/su", "/system/sd/xbin/su", "/system/app/Superuser.apk", "/data/adb/magisk"};
        for (String s : p) if (new File(s).exists()) return true;
        return Build.TAGS != null && Build.TAGS.contains("test-keys");
    }

    private static final String[] SAFE_A11Y = {"com.google.android.marvin.", "com.google.android.accessibility", "com.google.android.apps.accessibility",
        "com.samsung.android.accessibility", "com.samsung.accessibility", "com.samsung.android.app.talkback", "com.android.talkback", "com.android.switchaccess"};

    private static List<String> riskyAccessibility(Context c) {
        List<String> out = new ArrayList<>();
        try {
            String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null || s.isEmpty()) return out;
            for (String item : s.split(":")) {
                ComponentName cn = ComponentName.unflattenFromString(item);
                if (cn == null) continue;
                String pkg = cn.getPackageName();
                boolean safe = false;
                for (String p : SAFE_A11Y) if (pkg.startsWith(p)) safe = true;
                if (!safe && !out.contains(pkg)) out.add(pkg);
            }
        } catch (Exception e) { }
        return out;
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
