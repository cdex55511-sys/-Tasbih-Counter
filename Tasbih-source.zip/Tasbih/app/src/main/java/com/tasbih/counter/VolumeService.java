package com.tasbih.counter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.ToneGenerator;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.ViewConfiguration;

/**
 * Keeps a media session active with a silent looping track. Android then sends the
 * hardware volume buttons to this session, even with the screen off.
 */
public class VolumeService extends Service {
    static volatile boolean running;
    static volatile Runnable listener;
    static volatile Runnable stopListener;   // told when the service ends itself (long press), so a visible page can follow
    // Live state pushed by the page (memory only, so counting never waits on disk).
    static volatile int pCur;
    static volatile String pChain = "0";
    static volatile boolean fSnd = true;
    static volatile int fMs = 60, fRms = 120;

    private MediaSession session;
    private AudioTrack track;
    private ToneGenerator tone;
    private Vibrator vib;
    private SharedPreferences sp;
    private PressTracker pt;
    private long longMs;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable longRun = () -> { if (pt.onTimer(SystemClock.elapsedRealtime()) == PressTracker.LONG) stopByLongPress(); };

    @Override public IBinder onBind(Intent i) { return null; }

    static final String ACTION_STOP = "com.tasbih.counter.STOP";

    /** Never restarted by the system: if the app is removed or killed, counting stops with it. */
    @Override public int onStartCommand(Intent i, int f, int id) {
        if (i != null && ACTION_STOP.equals(i.getAction())) { stopForeground(Service.STOP_FOREGROUND_REMOVE); stopSelf(); }
        return START_NOT_STICKY;
    }

    /** Swiping the app out of Recents ends screen-off counting and removes the notification. */
    @Override public void onTaskRemoved(Intent root) {
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        stopSelf();
        super.onTaskRemoved(root);
    }

    @Override public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("tasbih", MODE_PRIVATE);
        longMs = ViewConfiguration.getLongPressTimeout();
        pt = new PressTracker(longMs, sp.getBoolean("upSeen", false));
        vib = getSystemService(Vibrator.class);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 70); } catch (Exception e) { tone = null; }
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel("tasbih", "Tasbih counting", NotificationManager.IMPORTANCE_LOW));
        buildSession();
        startSilentTrack();
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopPi = PendingIntent.getService(this, 1, new Intent(this, VolumeService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "tasbih")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Tasbih is counting")
            .setContentText("Either volume button counts. Hold one to stop.")
            .setContentIntent(pi)
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop counting", stopPi).build())
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()))
            .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
        running = true;
    }

    private void buildSession() {
        session = new MediaSession(this, "TasbihSession");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { count(1); }
            @Override public void onPause() { count(1); }
            @Override public void onSkipToNext() { count(1); }
            @Override public void onSkipToPrevious() { count(-1); }
        });
        setPlaying();
        session.setPlaybackToRemote(new VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
            @Override public void onAdjustVolume(int direction) { onVolume(direction); }
        });
        session.setActive(true);
    }

    private void setPlaying() {
        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
            .setState(PlaybackState.STATE_PLAYING, 0, 1f).build());
    }

    private void startSilentTrack() {
        int sr = 8000;
        short[] buf = new short[sr];
        for (int i = 0; i < buf.length; i++) buf[i] = (short) ((i % 2 == 0) ? 2 : -2);
        track = new AudioTrack.Builder()
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(buf.length * 2).build();
        track.write(buf, 0, buf.length);
        track.setLoopPoints(0, buf.length, -1);
        track.play();
    }

    /** Either volume button: one count per press (auto-repeat ignored); holding it turns screen-off counting off. */
    private void onVolume(int direction) {
        int r = pt.onAdjust(direction, SystemClock.elapsedRealtime());
        if (direction == 0) {
            h.removeCallbacks(longRun);
            if (!sp.getBoolean("upSeen", false)) sp.edit().putBoolean("upSeen", true).apply();
            return;
        }
        if (r == PressTracker.COUNT) {
            count(1);
            h.removeCallbacks(longRun);
            if (pt.timerWanted()) h.postDelayed(longRun, longMs);
        } else if (r == PressTracker.LONG) {
            stopByLongPress();
        }
    }

    private void stopByLongPress() {
        h.removeCallbacks(longRun);
        apply(-1, false);   // take back the count that this press made when it began
        try {
            if (fRms > 0 && vib != null) vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 70, 90, 70}, -1));
            if (fSnd && tone != null) tone.startTone(ToneGenerator.TONE_PROP_NACK, 250);
        } catch (Exception e) { }
        Runnable sl = stopListener;
        if (sl != null) sl.run();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void count(int d) { apply(d, true); }

    /** d = +1 count, -1 undo. Feedback fires first; bookkeeping after. */
    private void apply(int d, boolean feedback) {
        setPlaying();
        int cur = Math.max(0, Math.min(1000000, pCur + d));
        String chain = pChain;
        String[] ch = chain.split(",");
        int target = 0;
        try { target = Integer.parseInt(ch[0].trim()); } catch (Exception e) { }
        boolean round = d > 0 && target > 0 && cur >= target;
        if (feedback) { if (round) roundCue(); else cue(d > 0); }
        if (round) {
            cur = 0;
            if (ch.length > 1) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i < ch.length; i++) { if (i > 1) sb.append(','); sb.append(ch[i]); }
                chain = sb.toString();
            }
        }
        pCur = cur;
        pChain = chain;
        long now = System.currentTimeMillis();
        int dl = sp.getInt("delta", 0);
        sp.edit().putInt("delta", Math.max(-100000, Math.min(100000, dl + d)))
            .putLong("dfirst", dl == 0 ? now : sp.getLong("dfirst", now)).putLong("dlast", now).commit();
        Runnable l = listener;
        if (l != null) l.run();
    }

    private void cue(boolean up) {
        try {
            if (fMs > 0 && vib != null) vib.vibrate(VibrationEffect.createOneShot(fMs, VibrationEffect.DEFAULT_AMPLITUDE));
            if (fSnd && tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, up ? 40 : 70);
        } catch (Exception e) { }
    }

    private void roundCue() {
        try {
            if (fRms > 0 && vib != null)
                vib.vibrate(VibrationEffect.createWaveform(new long[]{0, fRms, 80, fRms}, -1));
            if (fSnd && tone != null) tone.startTone(ToneGenerator.TONE_PROP_ACK, 400);
        } catch (Exception e) { }
    }

    @Override public void onDestroy() {
        running = false;
        h.removeCallbacks(longRun);
        try { session.setActive(false); session.release(); } catch (Exception e) { }
        try { track.stop(); track.release(); } catch (Exception e) { }
        if (tone != null) tone.release();
        super.onDestroy();
    }
}
