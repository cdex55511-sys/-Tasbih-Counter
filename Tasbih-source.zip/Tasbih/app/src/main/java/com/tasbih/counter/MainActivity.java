package com.tasbih.counter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputFilter;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;

public class MainActivity extends Activity {
    /** true = no screenshots or screen recording, and the Recents preview is blanked. */
    private static final boolean SECURE_SCREEN = true;
    /** true = hide other apps' overlays and drop taps under them (needs API 31+ for the first part). Off by default because it
     *  also hides night-dimmer / blue-light-filter apps while Tasbih is open. */
    private static final boolean OVERLAY_PROTECTION = false;
    private static final String HOME = "file:///android_asset/index.html";

    private WebView web;
    private SharedPreferences sp;
    private Vibrator vib;
    private boolean loaded, keys, dead;
    private long lastBack;
    private boolean swallowVolUp;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (SECURE_SCREEN) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        if (OVERLAY_PROTECTION && Build.VERSION.SDK_INT >= 31) { try { getWindow().setHideOverlayWindows(true); } catch (Exception e) { } }
        getWindow().setStatusBarColor(0xFF06231C);
        getWindow().setNavigationBarColor(0xFF06231C);
        sp = getSharedPreferences("tasbih", MODE_PRIVATE);
        vib = getSystemService(Vibrator.class);
        SecurityGuard.Verdict v = SecurityGuard.scan(this);
        if (v.block != null) { fail(v.block); return; }
        keys = VolumeService.running;
        buildWeb();
        if (!v.warn.isEmpty()) warn(v.warn);
    }

    private void buildWeb() {
        web = new WebView(this);
        web.setBackgroundColor(0xFF06231C);
        web.setFilterTouchesWhenObscured(OVERLAY_PROTECTION);
        web.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setBlockNetworkLoads(true);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(false);   // no remote pages are ever loaded, so skip the lookup service
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) { loaded = true; applyDelta(); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (HOME.equals(r.getUrl().toString())) return null;
                return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) { h.cancel(); }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) { recreate(); return true; }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) { r.deny(); }
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback cb) { cb.invoke(o, false, false); }
            @Override public boolean onCreateWindow(WebView v, boolean d, boolean g, Message m) { return false; }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) { cb.onReceiveValue(null); return true; }
        });
        web.loadUrl(HOME);
    }

    private void fail(String msg) {
        dead = true;
        VolumeService.listener = null;
        try { stopService(new Intent(this, VolumeService.class)); } catch (Exception e) { }
        if (web != null) { web.removeJavascriptInterface("Android"); web.stopLoading(); web.setVisibility(View.GONE); }
        new AlertDialog.Builder(this).setTitle("Security check failed").setMessage(msg).setCancelable(false)
            .setPositiveButton("Exit", (d, w) -> finishAndRemoveTask()).show();
    }

    private void warn(List<String> w) {
        final String sig = String.join("|", w);
        if (sig.equals(sp.getString("ackwarn", ""))) return;
        new AlertDialog.Builder(this).setTitle("Security notice").setMessage(String.join("\n\n", w)).setCancelable(false)
            .setPositiveButton("Continue", (d, x) -> sp.edit().putString("ackwarn", sig).apply())
            .setNegativeButton("Exit", (d, x) -> finishAndRemoveTask()).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web == null || dead) return;
        keys = VolumeService.running;
        VolumeService.listener = this::applyDelta;
        VolumeService.stopListener = this::serviceStopped;
        applyDelta();
        if (loaded) web.evaluateJavascript("window.nativeService(" + VolumeService.running + ")", null);
        // Integrity scan runs off the main thread so resuming the app is never delayed.
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            SecurityGuard.Verdict v = SecurityGuard.scan(app);
            if (v.block != null) runOnUiThread(() -> { if (!dead) fail(v.block); });
        }).start();
    }

    @Override protected void onPause() {
        VolumeService.listener = null;
        VolumeService.stopListener = null;
        super.onPause();
    }

    @Override protected void onStart() {
        super.onStart();
        if (web != null && !dead) web.onResume();
    }

    @Override protected void onStop() {
        if (web != null && !dead) web.onPause();
        super.onStop();
    }

    /** Counts made by the service while the screen was off are handed to the page here. */
    private void applyDelta() {
        if (!loaded || dead || web == null) return;
        int d = sp.getInt("delta", 0);
        if (d == 0) return;
        d = Math.max(-100000, Math.min(100000, d));
        long first = sp.getLong("dfirst", 0), last = sp.getLong("dlast", 0);
        sp.edit().putInt("delta", 0).commit();
        web.evaluateJavascript("window.nativeApply(" + d + "," + first + "," + last + ")", null);
    }

    /** The service ended itself (volume-button long press): drop key capture and let the page follow. */
    private void serviceStopped() {
        keys = false;
        if (loaded && web != null && !dead) web.evaluateJavascript("window.nativeService(false)", null);
    }

    private boolean isVol(int k) { return k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN; }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        if (!dead && keys && web != null && isVol(k)) {
            if (e.getRepeatCount() == 0) {
                e.startTracking();   // lets Android tell us when the button is held (onKeyLongPress)
                web.evaluateJavascript("window.nativeVolume(" + (k == KeyEvent.KEYCODE_VOLUME_UP ? 1 : -1) + ")", null);
            }
            return true;
        }
        return super.onKeyDown(k, e);
    }

    /** Holding either volume button while screen-off counting is on turns it off. */
    @Override public boolean onKeyLongPress(int k, KeyEvent e) {
        if (!dead && keys && web != null && isVol(k)) {
            keys = false;
            swallowVolUp = true;
            MainActivity.this.stopService(new Intent(MainActivity.this, VolumeService.class));
            web.evaluateJavascript("window.nativeLongPress()", null);
            return true;
        }
        return super.onKeyLongPress(k, e);
    }

    @Override public boolean onKeyUp(int k, KeyEvent e) {
        if (isVol(k) && (swallowVolUp || (!dead && keys))) { swallowVolUp = false; return true; }
        return super.onKeyUp(k, e);
    }

    @Override public void onBackPressed() {
        if (web == null || dead) { finishAndRemoveTask(); return; }
        web.evaluateJavascript("(function(){var o=document.querySelector('.sheet.open,.modal.open');if(!o)return 0;close();document.getElementById('modal').classList.remove('open');return 1})()",
            v -> {
                if ("1".equals(v)) return;
                long n = System.currentTimeMillis();
                if (n - lastBack < 2000) { VolumeService.listener = null; MainActivity.this.stopService(new Intent(MainActivity.this, VolumeService.class)); keys = false; finish(); }
                else { lastBack = n; Toast.makeText(MainActivity.this, "Press back again to exit", Toast.LENGTH_SHORT).show(); }
            });
    }

    /** Text typed in the native dialog goes to the page as a quoted JSON string, control characters removed. */
    private void deliverText(String id, String text) {
        if (web == null || dead || !loaded || text == null) return;
        String t = text.replaceAll("[\\p{Cntrl}\u2028\u2029]", "");
        if (t.length() > 80) t = t.substring(0, 80);
        web.evaluateJavascript("window.nativeText(" + JSONObject.quote(id) + "," + JSONObject.quote(t) + ")", null);
    }

    /** Everything the page may ask the app to do. All inputs are validated, and nothing works after a failed security check. */
    private class Bridge {
        @JavascriptInterface public boolean isServiceOn() { return !dead && VolumeService.running; }

        @JavascriptInterface public void startService() {
            if (dead) return;
            runOnUiThread(() -> {
                if (dead) return;
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                startForegroundService(new Intent(MainActivity.this, VolumeService.class));
                keys = true;
            });
        }

        @JavascriptInterface public void stopService() {
            runOnUiThread(() -> { MainActivity.this.stopService(new Intent(MainActivity.this, VolumeService.class)); keys = false; });
        }

        @JavascriptInterface public void vibrate(int ms) {
            if (dead || vib == null || ms <= 0) return;
            vib.vibrate(VibrationEffect.createOneShot(Math.min(ms, 1000), VibrationEffect.DEFAULT_AMPLITUDE));
        }

        @JavascriptInterface public void vibrateRound(int ms) {
            if (dead || vib == null || ms <= 0) return;
            int m = Math.min(ms, 2000);
            vib.vibrate(VibrationEffect.createWaveform(new long[]{0, m, 80, m}, -1));
        }

        @JavascriptInterface public void setFeedback(boolean sound, int pulseMs, int roundMs) {
            if (dead) return;
            VolumeService.fSnd = sound;
            VolumeService.fMs = Math.max(0, Math.min(1000, pulseMs));
            VolumeService.fRms = Math.max(0, Math.min(2000, roundMs));
        }

        @JavascriptInterface public void setCur(int cur) {
            if (!dead) VolumeService.pCur = Math.max(0, Math.min(1000000, cur));
        }

        @JavascriptInterface public void setChain(String chain) {
            if (dead) return;
            VolumeService.pChain = (chain != null && chain.matches("[0-9]{1,6}(,[0-9]{1,6}){0,63}")) ? chain : "0";
        }

        /** Native text box: Android's own EditText, so every keyboard language and switching works. */
        @JavascriptInterface public void editText(String id, String title, String initial, boolean rtl) {
            if (dead) return;
            final String tid = id == null ? "" : id.replaceAll("[^A-Za-z0-9]", "");
            final String ttl = title == null ? "" : title.substring(0, Math.min(title.length(), 40));
            final String init = initial == null ? "" : initial.substring(0, Math.min(initial.length(), 80));
            runOnUiThread(() -> {
                if (dead) return;
                final EditText et = new EditText(MainActivity.this);
                et.setSingleLine(true);
                et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
                et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});
                if (rtl) et.setTextDirection(View.TEXT_DIRECTION_RTL);
                et.setText(init);
                et.setSelection(et.getText().length());
                float d = getResources().getDisplayMetrics().density;
                int pad = Math.round(20 * d);
                LinearLayout box = new LinearLayout(MainActivity.this);
                box.setPadding(pad, Math.round(8 * d), pad, 0);
                box.addView(et, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                AlertDialog dlg = new AlertDialog.Builder(MainActivity.this).setTitle(ttl).setView(box)
                    .setPositiveButton("OK", (x, w) -> deliverText(tid, et.getText().toString()))
                    .setNegativeButton("Cancel", null).create();
                dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                dlg.show();
            });
        }

        /** Window brightness override (this window only): minimum while on, the normal setting when off. */
        @JavascriptInterface public void setDim(boolean on) {
            if (dead) return;
            runOnUiThread(() -> {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = on ? 0.01f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                getWindow().setAttributes(lp);
            });
        }

        /** Counter area (CSS px, top/bottom). Edge swipes there are kept away from the system Back gesture. */
        @JavascriptInterface public void setGestureZone(int top, int bottom) {
            if (dead || Build.VERSION.SDK_INT < 29) return;
            runOnUiThread(() -> {
                if (web == null || dead) return;
                float d = getResources().getDisplayMetrics().density;
                int w = web.getWidth(), e = Math.round(40 * d), half = Math.round(100 * d);
                int cy = Math.round((Math.max(0, top) + Math.max(top, bottom)) / 2f * d);
                web.setSystemGestureExclusionRects(Arrays.asList(new Rect(0, cy - half, e, cy + half), new Rect(w - e, cy - half, w, cy + half)));
            });
        }

        @JavascriptInterface public void setKeepAwake(boolean on) {
            if (dead) return;
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }
}
