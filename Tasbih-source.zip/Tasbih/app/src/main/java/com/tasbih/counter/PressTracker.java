package com.tasbih.counter;

/**
 * Turns the stream of volume-key adjustments into "one count per press" and "long press".
 * Android calls the session with direction +1/-1 on key-down (and again on every auto-repeat while held)
 * and with direction 0 on key-up. Pure logic, no Android classes, so it can be unit-tested.
 */
final class PressTracker {
    static final int NONE = 0, COUNT = 1, LONG = 2;
    private static final long LOST_UP_MS = 700;   // silence this long means the release was missed

    private final long longMs;
    private boolean pressed, longFired;
    private long pressAt, lastEvt;
    boolean upSeen;   // true once a key-up has been observed, so a hold timer can be trusted

    PressTracker(long longMs, boolean upSeen) { this.longMs = longMs; this.upSeen = upSeen; }

    /** direction: +1 / -1 = key down or auto-repeat, 0 = key released. */
    int onAdjust(int direction, long now) {
        if (direction == 0) { upSeen = true; pressed = false; return NONE; }
        if (pressed && now - lastEvt > LOST_UP_MS) pressed = false;
        lastEvt = now;
        if (!pressed) { pressed = true; longFired = false; pressAt = now; return COUNT; }
        if (!longFired && now - pressAt >= longMs) { longFired = true; return LONG; }
        return NONE;   // auto-repeat of a key already counted
    }

    /** Fired longMs after a press began. Only trusted once releases are known to be delivered. */
    int onTimer(long now) {
        if (upSeen && pressed && !longFired && now - pressAt >= longMs) { longFired = true; return LONG; }
        return NONE;
    }

    boolean timerWanted() { return upSeen; }
}
