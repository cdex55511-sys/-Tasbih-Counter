# Tasbih for Android (hardened)

## 1. One-time: create your own signing key (do this once, keep the file safe)
    keytool -genkeypair -v -keystore release.jks -alias tasbih -keyalg RSA -keysize 4096 -validity 36500
(When asked for the key password, press RETURN so it is the same as the keystore password; then KS_PASS and KEY_PASS are identical.)
    base64 -w0 release.jks        # macOS: base64 -i release.jks

In GitHub: Settings > Secrets and variables > Actions > New repository secret. Add four secrets:
`KEYSTORE_B64` (the base64 text), `KS_PASS`, `KEY_ALIAS` (tasbih), `KEY_PASS`.
Back up release.jks somewhere offline. If you lose it you can never update the app, and never commit it to the repo.

## 2. Build
Push to GitHub, open Actions > Build secure APK, download `tasbih-apk`.
With the secrets present you get a signed, shrunk, obfuscated release APK that refuses to run if re-signed.
Without them you get a debug APK (integrity checks that need your key are skipped).
Uninstall the old version first: the signing key changed, so Android treats it as a different app and its counts are lost.

## 3. If you edit app/src/main/assets/index.html
Run `python3 tools/seal.py` (CI does this for you). It updates the page's Content-Security-Policy hash.

## Defence layers
1. No INTERNET permission, cleartext off, WebView network loads blocked: nothing can leave or enter over the network.
2. WebView lock-down: only the bundled page may load, navigation and popups blocked, no file/content access,
   permissions (camera, mic, location) denied, remote debugging off, autofill off, tap-jacking and overlay protection.
3. Strict Content-Security-Policy (script hash only, no network, no frames) plus no remote fonts.
4. JS bridge: five methods only, every argument range-checked, disabled after any failed security check.
5. Saved data is rebuilt from a whitelist on every load (types, ranges, ids), so corrupted or tampered storage cannot inject anything.
6. Runtime checks at launch and every resume: signature matches your key, page hash matches the build,
   no debugger / ptrace, no Frida or Xposed. Failing any of these stops the app. Rooted devices and unknown
   accessibility services trigger a warning (set `BLOCK_ROOTED = true` in SecurityGuard.java to refuse instead).
7. Backups disabled (no adb or cloud extraction), task-hijack protection, screenshots and screen recording blocked
   (set `SECURE_SCREEN = false` in MainActivity.java to allow screenshots).
   Overlay protection is available but OFF by default (`OVERLAY_PROTECTION = true`), because it also hides
   night-dimmer / blue-light-filter apps and makes taps under any overlay do nothing.
8. Release build is shrunk and obfuscated (R8); CI runs with read-only permissions and deletes the keystore after use.

## Honest limits
On a rooted or fully compromised phone, no app can guarantee safety, and a determined attacker can patch out the
checks. These layers stop casual tampering, repackaged copies, other apps, network attacks and bad data. The app
stores only counters, no passwords or personal data, so there is little worth stealing.
If the page ever shows blank after a change, the first thing to check is that `tools/seal.py` has been run.

## What changed in 2.1
Speed: counting now reacts on touch-down, vibration is sent straight to the phone's motor before anything else runs,
saving is batched instead of written on every tap, and the heavy visual effects were replaced with cheap GPU ones.
Home screen: the "All time" box is now a round timer (starts on the first count, stops when the round finishes,
tap to stop/start, long press to reset, pauses after 3 idle minutes). All-time total moved to Settings > Progress.
Defaults: counter at maximum size, vibration Medium (60 ms).

## What changed in 2.2
Swipe to count (Settings > Design): a swipe that starts in the counter area counts like a touch.
Modes: Off, One per swipe (default), Keep counting while swiping (one more count per finger-length).
Edge swipes around the counter are kept away from Android's Back gesture (Android 10+), and Back now asks you to
press it twice to exit, so a stray edge swipe can no longer close the app.

## What changed in 2.3
- One count per touch: from the first finger down until every finger is up, only one count is possible (long, fast or
  winding swipes, a second finger, a resting palm: still one). The old "keep counting while swiping" mode is gone.
- Custom dhikr / dua names use Android's own text box, so every keyboard language works and switching languages is safe.
- Screen-off counting stops when the app is removed from Recents (and when you exit with Back). The notification has a
  Stop button, and the service is never restarted automatically.
- Dim button in the header sets the screen to minimum brightness (this app only). Swipe UP with two fingers anywhere to
  restore normal brightness, swipe DOWN with two fingers to dim again. Pinch zoom is disabled so two-finger swipes work.

## What changed in 2.4
- Screen-off counting: BOTH volume buttons now count (one count per press; holding does not repeat-count).
  Headset "previous" still undoes. The old "Both volume keys count" option is gone because it is now always on.
- Holding either volume button (your phone's touch-and-hold delay) turns screen-off counting off: the count made when the
  press began is taken back, you get a double buzz and a tone, the notification disappears. Works with the screen on or off.
  If your phone never reports key releases to media sessions, the hold timer stays disabled for safety and you can still
  stop with the notification's Stop button.
